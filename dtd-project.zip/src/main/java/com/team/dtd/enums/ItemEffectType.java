package com.team.dtd.enums;

public enum ItemEffectType {
    HEAL, BUFF_ATK, BOMB, STUN, TICKET, DATA
}