package com.team.dtd.enums;

public enum TowerType {
    FIRE, PLANT, ELECTRIC, WATER, LIGHT, DARK
}