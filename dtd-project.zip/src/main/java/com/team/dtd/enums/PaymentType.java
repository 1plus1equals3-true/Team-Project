package com.team.dtd.enums;

public enum PaymentType {
    GOLD, DIAMOND
}