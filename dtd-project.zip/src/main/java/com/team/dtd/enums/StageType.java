package com.team.dtd.enums;

public enum StageType {
    DEFENSE, BOSS
}