package com.team.dtd.enums;

public enum RewardType {
    DIAMOND, GOLD, ITEM
}