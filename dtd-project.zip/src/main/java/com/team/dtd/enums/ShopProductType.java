package com.team.dtd.enums;

public enum ShopProductType {
    DIAMOND_BUNDLE,
    GOLD_BUNDLE,
    SPECIAL_PACKAGE
}