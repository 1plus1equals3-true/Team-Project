package com.team.dtd;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DtdApplicationTests {

	@Test
	void contextLoads() {
	}

}
