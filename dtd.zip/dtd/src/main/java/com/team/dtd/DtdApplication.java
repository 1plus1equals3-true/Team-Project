package com.team.dtd;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DtdApplication {

	public static void main(String[] args) {
		SpringApplication.run(DtdApplication.class, args);
	}

}
